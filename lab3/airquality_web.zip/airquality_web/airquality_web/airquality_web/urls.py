"""Root URL configuration for airquality_web."""
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path
from django.views.i18n import JavaScriptCatalog

# `set_language` (used by the language switcher in templates/includes/navbar.html)
# must stay OUTSIDE i18n_patterns - it is the view that toggles the active
# language itself, so it cannot live behind a language-prefixed path.
urlpatterns = [
    path("i18n/", include("django.conf.urls.i18n")),
    path("jsi18n/", JavaScriptCatalog.as_view(), name="javascript-catalog"),
]

urlpatterns += [
    # Built-in Django administration site. Useful as a low-level data
    # browser for superusers; the project's own role-based admin
    # interface lives under /admin-panel/ (see adminpanel.urls).
    path("django-admin/", admin.site.urls),
    path("admin-panel/", include("adminpanel.urls")),
    path("accounts/", include("accounts.urls")),
    path("", include("monitoring.urls")),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
