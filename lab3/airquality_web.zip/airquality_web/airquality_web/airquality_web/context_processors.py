"""Custom template context processors for the project."""
from django.conf import settings


def site_branding(request):
    """Expose simple branding/version info to every template."""
    return {
        "SITE_NAME": "AirWatch",
        "BACKEND_API_BASE_URL": getattr(settings, "BACKEND_API_BASE_URL", ""),
    }
