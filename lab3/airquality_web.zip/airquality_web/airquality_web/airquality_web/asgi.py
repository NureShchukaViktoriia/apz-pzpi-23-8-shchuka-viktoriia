"""ASGI config for airquality_web project."""
import os

from django.core.asgi import get_asgi_application

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "airquality_web.settings")

application = get_asgi_application()
