"""
Django settings for the air_quality_web front-end application.

This project is the web front-end (Лабораторна робота №3) for the
"Air Quality Monitoring System" described in the Vision & Scope document.
It provides:
  * a public / authenticated user-facing interface (monitoring app);
  * a separate administration interface (adminpanel app) for users with
    the "admin" role: user management, data management, backups,
    import/export of data and settings;
  * full internationalisation / localisation support (Ukrainian / English).

For more information see https://docs.djangoproject.com/en/5.0/topics/settings/
"""

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

# ---------------------------------------------------------------------------
# Core / security
# ---------------------------------------------------------------------------

SECRET_KEY = os.environ.get(
    "DJANGO_SECRET_KEY",
    "django-insecure-CHANGE-ME-before-deploying-to-production-!!!",
)

DEBUG = os.environ.get("DJANGO_DEBUG", "True") == "True"

ALLOWED_HOSTS = os.environ.get("DJANGO_ALLOWED_HOSTS", "*").split(",")

# ---------------------------------------------------------------------------
# Applications
# ---------------------------------------------------------------------------

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "django.contrib.humanize",

    # Project apps
    "accounts",
    "monitoring",
    "adminpanel",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    # LocaleMiddleware MUST come after SessionMiddleware and before
    # CommonMiddleware: it is the component responsible for choosing the
    # active language (session > cookie > Accept-Language header > default).
    "django.middleware.locale.LocaleMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "airquality_web.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
                "django.template.context_processors.i18n",
                "airquality_web.context_processors.site_branding",
            ],
        },
    },
]

WSGI_APPLICATION = "airquality_web.wsgi.application"
ASGI_APPLICATION = "airquality_web.asgi.application"

# ---------------------------------------------------------------------------
# Database
#
# The front-end keeps its own data store (users, zones, devices, sensor
# types, measurements, system settings). In production it is configured to
# point at the same PostgreSQL instance used by the REST API back-end
# (Лабораторна робота №2), see README.md for the docker-compose layout and
# the Component Diagram in the report for the chosen deployment topology.
# For local development / grading SQLite is used as a zero-configuration
# default so the project runs out of the box.
# ---------------------------------------------------------------------------

if os.environ.get("DATABASE_URL_ENGINE") == "postgresql":
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.postgresql",
            "NAME": os.environ.get("DATABASE_NAME", "airquality"),
            "USER": os.environ.get("DATABASE_USER", "postgres"),
            "PASSWORD": os.environ.get("DATABASE_PASSWORD", ""),
            "HOST": os.environ.get("DATABASE_HOST", "localhost"),
            "PORT": os.environ.get("DATABASE_PORT", "5432"),
        }
    }
else:
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.sqlite3",
            "NAME": BASE_DIR / "db.sqlite3",
        }
    }

AUTH_USER_MODEL = "accounts.CustomUser"

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator", "OPTIONS": {"min_length": 8}},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

# ---------------------------------------------------------------------------
# Internationalisation / Localisation
#
# Requirement: "підтримка української та англійської мов сайту, формат
# дати та часу відповідний регіону, порядок сортування текстових значень,
# різні напрями введення тексту тощо".
# ---------------------------------------------------------------------------

LANGUAGE_CODE = "uk"  # default site language

LANGUAGES = [
    ("uk", "Українська"),
    ("en", "English"),
]

# Where compiled .po/.mo translation catalogues live.
LOCALE_PATHS = [BASE_DIR / "locale"]

# Languages that read right-to-left. None of the two shipped languages are
# RTL, but LANGUAGE_BIDI / BIDI_DETECTION below is what Django (and our
# base.html <html dir="..."> attribute) uses to decide text direction, so
# adding e.g. Arabic or Hebrew in the future automatically renders RTL
# without any further template changes.
TIME_ZONE = "Europe/Kyiv"

USE_I18N = True
USE_L10N = True  # locale-aware date/number formatting (kept explicit for clarity)
USE_TZ = True

# ---------------------------------------------------------------------------
# Static & media files
# ---------------------------------------------------------------------------

STATIC_URL = "static/"
STATICFILES_DIRS = [BASE_DIR / "static"]
STATIC_ROOT = BASE_DIR / "staticfiles"

MEDIA_URL = "/media/"
MEDIA_ROOT = BASE_DIR / "media"

# Sub-directories used by the administration module.
BACKUPS_DIR = MEDIA_ROOT / "backups"
EXPORTS_DIR = MEDIA_ROOT / "exports"
IMPORTS_DIR = MEDIA_ROOT / "imports"

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# ---------------------------------------------------------------------------
# Auth flow
# ---------------------------------------------------------------------------

LOGIN_URL = "accounts:login"
LOGIN_REDIRECT_URL = "monitoring:dashboard"
LOGOUT_REDIRECT_URL = "monitoring:dashboard"

# ---------------------------------------------------------------------------
# Integration with the Лабораторна робота №2 REST API back-end
#
# The front-end can optionally pull/push data through the existing Flask
# REST API (air_quality_backend) instead of (or in addition to) its own
# database, e.g. for synchronising IoT measurements collected by the
# back-end service. See monitoring/services/backend_client.py and the
# "sync_from_backend" management command.
# ---------------------------------------------------------------------------

BACKEND_API_BASE_URL = os.environ.get("BACKEND_API_BASE_URL", "http://localhost:5000")
BACKEND_API_TIMEOUT_SECONDS = float(os.environ.get("BACKEND_API_TIMEOUT_SECONDS", "5"))

# Simplified Air Quality Index thresholds used by monitoring.services.aqi.
# Documented in the report as an explicit engineering assumption: this is an
# educational simplification of real-world AQI breakpoint tables, not an
# official regulatory standard.
AQI_CATEGORY_COUNT = 5
