# -*- coding: utf-8 -*-
"""
A tiny, dependency-free .po -> .mo compiler.

This project ships pre-compiled translation catalogues so that
`django-admin compilemessages` (which shells out to the system's GNU
gettext `msgfmt` binary) is not a hard requirement for grading/demo
purposes - many minimal environments (including the one used to author
this project) do not have `msgfmt` installed. Re-run this script after
editing locale/uk/LC_MESSAGES/django.po if you don't have `msgfmt`
available; otherwise `python manage.py compilemessages` works too and
produces an equivalent file.

Usage:
    python3 build_mo.py <input.po> <output.mo>
"""
import struct
import sys


def unescape(raw: str) -> str:
    """Reverses the escaping rules used by build_po.py's escape()."""
    result = []
    i = 0
    while i < len(raw):
        ch = raw[i]
        if ch == "\\" and i + 1 < len(raw):
            nxt = raw[i + 1]
            if nxt == "n":
                result.append("\n")
                i += 2
                continue
            if nxt == "t":
                result.append("\t")
                i += 2
                continue
            if nxt == '"':
                result.append('"')
                i += 2
                continue
            if nxt == "\\":
                result.append("\\")
                i += 2
                continue
        result.append(ch)
        i += 1
    return "".join(result)


def parse_quoted(line: str) -> str:
    """Extracts the content of a double-quoted PO string literal."""
    line = line.strip()
    assert line.startswith('"') and line.endswith('"'), f"Not a quoted string: {line!r}"
    return unescape(line[1:-1])


def parse_po(path: str):
    entries = []  # list of (msgid, msgstr)
    msgid_parts = None
    msgstr_parts = None
    target = None  # "id" or "str"

    def flush():
        nonlocal msgid_parts, msgstr_parts, target
        if msgid_parts is not None and msgstr_parts is not None:
            entries.append(("".join(msgid_parts), "".join(msgstr_parts)))
        msgid_parts = None
        msgstr_parts = None
        target = None

    with open(path, "r", encoding="utf-8") as fh:
        for raw_line in fh:
            line = raw_line.rstrip("\n")
            stripped = line.strip()
            if not stripped:
                flush()
                continue
            if stripped.startswith("#"):
                continue
            if stripped.startswith("msgid "):
                flush()
                msgid_parts = [parse_quoted(stripped[len("msgid "):])]
                target = "id"
                continue
            if stripped.startswith("msgstr "):
                msgstr_parts = [parse_quoted(stripped[len("msgstr "):])]
                target = "str"
                continue
            if stripped.startswith('"'):
                value = parse_quoted(stripped)
                if target == "id":
                    msgid_parts.append(value)
                elif target == "str":
                    msgstr_parts.append(value)
                continue
        flush()
    return entries


def write_mo(entries, output_path: str):
    # Sort by msgid, as msgfmt does, with the header (msgid == "") first.
    entries = sorted(entries, key=lambda kv: kv[0])

    keys = [k.encode("utf-8") for k, _v in entries]
    values = [v.encode("utf-8") for _k, v in entries]

    key_offsets = []
    value_offsets = []
    key_block = b""
    value_block = b""

    for key in keys:
        key_offsets.append((len(key), len(key_block)))
        key_block += key + b"\x00"
    for value in values:
        value_offsets.append((len(value), len(value_block)))
        value_block += value + b"\x00"

    n = len(entries)
    # Header is 7 * 4 bytes = 28 bytes.
    keystart = 28 + 8 * n + 8 * n
    valuestart = keystart + len(key_block)

    koffsets = []
    voffsets = []
    running = keystart
    for length, offset in key_offsets:
        koffsets.append((length, running + offset))
    running = valuestart
    for length, offset in value_offsets:
        voffsets.append((length, running + offset))

    output = struct.pack("IIIIIII", 0x950412DE, 0, n, 28, 28 + 8 * n, 0, 28 + 16 * n)
    for length, offset in koffsets:
        output += struct.pack("II", length, offset)
    for length, offset in voffsets:
        output += struct.pack("II", length, offset)
    output += key_block
    output += value_block

    with open(output_path, "wb") as fh:
        fh.write(output)


def main():
    if len(sys.argv) != 3:
        print("Usage: build_mo.py <input.po> <output.mo>")
        sys.exit(1)
    entries = parse_po(sys.argv[1])
    write_mo(entries, sys.argv[2])
    print(f"Wrote {len(entries)} entries to {sys.argv[2]}")


if __name__ == "__main__":
    main()
