"""
Simplified Air Quality Index (AQI) calculation.

ENGINEERING ASSUMPTION (documented in the report, section "Прийняті
інженерні рішення"): real AQI standards (US EPA, EAQI, etc.) use
pollutant-specific NowCast/rolling-average algorithms that require
several additional inputs (averaging windows, calibration data) that are
outside the scope of this lab. For demonstration purposes this module
implements a simplified, but still pollutant-aware, breakpoint table:
for every supported sensor code the latest raw reading is mapped to one
of five qualitative categories, and a zone's overall AQI category is the
*worst* (maximum) category across all of its sensors - the same
"dominant pollutant" principle real AQI systems use.

Sensor codes not present in BREAKPOINTS (e.g. TEMPERATURE, HUMIDITY,
PRESSURE) are informational only and do not contribute to the AQI.
"""
from dataclasses import dataclass


@dataclass(frozen=True)
class AQICategory:
    index: int
    key: str
    color: str


CATEGORIES = [
    AQICategory(0, "good", "#2ecc71"),
    AQICategory(1, "moderate", "#f1c40f"),
    AQICategory(2, "unhealthy_sensitive", "#e67e22"),
    AQICategory(3, "unhealthy", "#e74c3c"),
    AQICategory(4, "hazardous", "#7d3c98"),
]

CATEGORY_LABELS = {
    "good": "Good",
    "moderate": "Moderate",
    "unhealthy_sensitive": "Unhealthy for sensitive groups",
    "unhealthy": "Unhealthy",
    "hazardous": "Hazardous",
}

# Upper bound (inclusive) of each category, per pollutant sensor code.
# Units must match the corresponding SensorType.unit used when seeding data.
BREAKPOINTS = {
    "CO2": [800, 1000, 1500, 2000],       # ppm
    "NO2": [53, 100, 360, 649],            # µg/m3 (approximate)
    "SO2": [35, 75, 185, 304],             # µg/m3 (approximate)
    "O3": [54, 70, 85, 105],               # µg/m3 (approximate)
    "PM25": [12, 35, 55, 150],             # µg/m3 (approximate)
    "PM10": [54, 154, 254, 354],           # µg/m3 (approximate)
}


def categorize(sensor_code: str, value: float) -> AQICategory | None:
    """Returns the AQICategory for a single pollutant reading, or None if
    the sensor code does not participate in the AQI calculation."""
    thresholds = BREAKPOINTS.get(sensor_code.upper())
    if thresholds is None:
        return None
    for index, upper_bound in enumerate(thresholds):
        if value <= upper_bound:
            return CATEGORIES[index]
    return CATEGORIES[-1]


def zone_aqi(latest_readings: dict) -> AQICategory | None:
    """Given a mapping {sensor_code: Measurement}, returns the worst
    (dominant) AQICategory across all pollutant readings, or None if no
    AQI-relevant pollutant has been measured yet."""
    worst = None
    for code, measurement in latest_readings.items():
        category = categorize(code, float(measurement.value))
        if category is None:
            continue
        if worst is None or category.index > worst.index:
            worst = category
    return worst
