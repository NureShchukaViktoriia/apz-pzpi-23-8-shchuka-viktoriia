"""
Thin HTTP client for the REST API back-end built in Лабораторна робота
№2 (air_quality_backend, Flask + SQLAlchemy + PostgreSQL).

The front-end's own database (this Django project) is authoritative for
demo/offline operation, but in the target deployment architecture
(see the report's Component Diagram) IoT devices write measurements to
the back-end's REST API, and this client lets the front-end pull that
data in periodically via the `sync_from_backend` management command, or
push locally-entered data back if needed.

All methods raise `requests.RequestException` on network failures - the
caller (the management command) is responsible for catching and logging
that, so a temporarily unreachable back-end never crashes the web app
itself.
"""
from django.conf import settings

import requests


class BackendClient:
    def __init__(self, base_url: str | None = None, timeout: float | None = None):
        self.base_url = (base_url or settings.BACKEND_API_BASE_URL).rstrip("/")
        self.timeout = timeout or settings.BACKEND_API_TIMEOUT_SECONDS

    def health(self) -> bool:
        response = requests.get(f"{self.base_url}/health", timeout=self.timeout)
        response.raise_for_status()
        return response.json().get("status") == "ok"

    def list_zones(self) -> list[dict]:
        response = requests.get(f"{self.base_url}/api/zones", timeout=self.timeout)
        response.raise_for_status()
        return response.json()

    def list_devices(self, zone_id: int | None = None) -> list[dict]:
        params = {"zone_id": zone_id} if zone_id else {}
        response = requests.get(f"{self.base_url}/api/devices", params=params, timeout=self.timeout)
        response.raise_for_status()
        return response.json()

    def list_sensor_types(self) -> list[dict]:
        response = requests.get(f"{self.base_url}/api/sensor-types", timeout=self.timeout)
        response.raise_for_status()
        return response.json()

    def list_measurements(self, device_id: int | None = None, sensor_type_id: int | None = None, limit: int = 500) -> list[dict]:
        params = {"limit": limit}
        if device_id:
            params["device_id"] = device_id
        if sensor_type_id:
            params["sensor_type_id"] = sensor_type_id
        response = requests.get(f"{self.base_url}/api/measurements", params=params, timeout=self.timeout)
        response.raise_for_status()
        return response.json()
