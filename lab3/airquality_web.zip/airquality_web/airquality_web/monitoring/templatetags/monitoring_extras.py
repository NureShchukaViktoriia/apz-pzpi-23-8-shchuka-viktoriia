from django import template
from django.utils.translation import gettext_lazy as _

from monitoring.services.aqi import CATEGORY_LABELS

register = template.Library()

_TRANSLATED_LABELS = {
    "good": _("Good"),
    "moderate": _("Moderate"),
    "unhealthy_sensitive": _("Unhealthy for sensitive groups"),
    "unhealthy": _("Unhealthy"),
    "hazardous": _("Hazardous"),
}


@register.filter
def aqi_label(category):
    if category is None:
        return _("No data")
    return _TRANSLATED_LABELS.get(category.key, category.key)


@register.filter
def aqi_color(category):
    if category is None:
        return "#95a5a6"
    return category.color
