"""
Locale-aware text sorting.

Requirement: "порядок сортування текстових значень" (sort order of text
values must follow the active locale).

We deliberately do NOT rely on `locale.setlocale(locale.LC_COLLATE, ...)`
because that requires the `uk_UA.UTF-8` / `en_US.UTF-8` locale packages to
be installed on the *server* OS, which cannot be guaranteed for every
deployment target (and is not installed in many minimal container images).
Instead we ship an explicit Ukrainian alphabet collation table, which makes
sorting deterministic and fully portable.

Ukrainian alphabet order (33 letters, э/ы/ё excluded - not used in modern
Ukrainian): А Б В Г Ґ Д Е Є Ж З И І Ї Й К Л М Н О П Р С Т У Ф Х Ц Ч Ш Щ Ь Ю Я
"""
from django.utils.translation import get_language

_UK_ALPHABET = "АБВГҐДЕЄЖЗИІЇЙКЛМНОПРСТУФХЦЧШЩЬЮЯ"
_UK_ORDER = {ch: index for index, ch in enumerate(_UK_ALPHABET)}


def _uk_sort_key(text: str):
    key = []
    for char in text.upper():
        key.append(_UK_ORDER.get(char, 1000 + ord(char)))
    return key


def localized_sort(items, key=lambda item: str(item), language: str | None = None, reverse: bool = False):
    """Sorts an iterable of items using the collation rules of the active
    (or explicitly given) language.

    * 'uk' -> Ukrainian alphabet order (Cyrillic-aware).
    * anything else (e.g. 'en') -> case-insensitive ASCII/Unicode order,
      which is correct for English text.
    """
    language = (language or get_language() or "uk").split("-")[0]
    items = list(items)
    if language == "uk":
        return sorted(items, key=lambda item: _uk_sort_key(key(item)), reverse=reverse)
    return sorted(items, key=lambda item: key(item).casefold(), reverse=reverse)
