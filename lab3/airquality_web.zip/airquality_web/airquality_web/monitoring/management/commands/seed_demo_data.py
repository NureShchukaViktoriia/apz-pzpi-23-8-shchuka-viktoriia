"""
Populates the database with demonstration data: monitoring zones in
Kharkiv, a handful of IoT devices, the sensor types used in MF-1
("температура, вологість, ... CO2, NO2, SO2, O3 ...") and a week of
synthetic measurements, so the front-end can be demoed without a live
connection to the Лабораторна робота №2 back-end.

Usage:
    python manage.py seed_demo_data
    python manage.py seed_demo_data --reset
"""
import random
from datetime import timedelta

from django.core.management.base import BaseCommand
from django.utils import timezone

from accounts.models import CustomUser
from monitoring.models import Device, Measurement, SensorType, Zone

ZONES = [
    {"name": "Центр", "region": "Харків", "latitude": 49.9935, "longitude": 36.230383},
    {"name": "Шевченківський район", "region": "Харків", "latitude": 50.0080, "longitude": 36.2360},
    {"name": "Індустріальний район", "region": "Харків", "latitude": 49.9420, "longitude": 36.3550},
    {"name": "Київський район", "region": "Харків", "latitude": 50.0260, "longitude": 36.2780},
    {"name": "Промислова зона \u2116 1", "region": "Харківська область", "latitude": 49.8200, "longitude": 36.1500},
]

SENSOR_TYPES = [
    {"code": "TEMPERATURE", "name": "Температура повітря", "unit": "\u00b0C", "base": 18, "spread": 8},
    {"code": "HUMIDITY", "name": "Вологість повітря", "unit": "%", "base": 55, "spread": 20},
    {"code": "CO2", "name": "Діоксид вуглецю", "unit": "ppm", "base": 600, "spread": 500},
    {"code": "NO2", "name": "Діоксид азоту", "unit": "\u00b5g/m3", "base": 30, "spread": 80},
    {"code": "SO2", "name": "Діоксид сірки", "unit": "\u00b5g/m3", "base": 15, "spread": 60},
    {"code": "O3", "name": "Озон", "unit": "\u00b5g/m3", "base": 25, "spread": 50},
]


class Command(BaseCommand):
    help = "Seeds the database with demonstration zones, devices, sensor types and measurements."

    def add_arguments(self, parser):
        parser.add_argument(
            "--reset",
            action="store_true",
            help="Delete existing monitoring data before seeding.",
        )
        parser.add_argument(
            "--days", type=int, default=7, help="How many days of measurement history to generate."
        )

    def handle(self, *args, **options):
        if options["reset"]:
            self.stdout.write("Removing existing monitoring data...")
            Measurement.objects.all().delete()
            Device.objects.all().delete()
            Zone.objects.all().delete()
            SensorType.objects.all().delete()

        sensor_types = {}
        for spec in SENSOR_TYPES:
            sensor_type, _created = SensorType.objects.get_or_create(
                code=spec["code"], defaults={"name": spec["name"], "unit": spec["unit"]}
            )
            sensor_types[spec["code"]] = (sensor_type, spec["base"], spec["spread"])

        zones = []
        for spec in ZONES:
            zone, _created = Zone.objects.get_or_create(
                name=spec["name"],
                region=spec["region"],
                defaults={"latitude": spec["latitude"], "longitude": spec["longitude"]},
            )
            zones.append(zone)

        devices = []
        now = timezone.now()
        for zone in zones:
            for index in range(1, 3):
                serial = f"DEV-{zone.pk:03d}-{index}"
                device, _created = Device.objects.get_or_create(
                    serial_number=serial,
                    defaults={"zone": zone, "status": Device.Status.ONLINE, "last_seen_at": now},
                )
                devices.append(device)

        self.stdout.write(f"Generating {options['days']} day(s) of synthetic measurements...")
        measurements = []
        interval_hours = 1
        steps = options["days"] * 24 // interval_hours
        for device in devices:
            for step in range(steps):
                measured_at = now - timedelta(hours=interval_hours * step)
                for code, (sensor_type, base, spread) in sensor_types.items():
                    value = max(0.0, base + random.uniform(-spread, spread) * 0.5)
                    measurements.append(
                        Measurement(
                            device=device,
                            sensor_type=sensor_type,
                            value=round(value, 3),
                            measured_at=measured_at,
                            quality_flag=Measurement.Quality.OK,
                        )
                    )
        Measurement.objects.bulk_create(measurements, batch_size=1000)

        if not CustomUser.objects.filter(username="admin").exists():
            CustomUser.objects.create_superuser(
                username="admin", email="admin@example.com", password="ChangeMe123!", role=CustomUser.Role.ADMIN
            )
            self.stdout.write(self.style.WARNING("Created superuser 'admin' / 'ChangeMe123!' - change this password."))

        if not CustomUser.objects.filter(username="analyst").exists():
            CustomUser.objects.create_user(
                username="analyst",
                email="analyst@example.com",
                password="ChangeMe123!",
                role=CustomUser.Role.ANALYST,
            )

        self.stdout.write(
            self.style.SUCCESS(
                f"Seeded {len(zones)} zones, {len(devices)} devices, {len(measurements)} measurements."
            )
        )
