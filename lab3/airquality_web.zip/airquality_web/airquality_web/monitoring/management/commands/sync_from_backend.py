"""
Pulls Zones / Devices / SensorTypes / Measurements from the Лабораторна
робота №2 REST API back-end into the front-end's own database.

Usage:
    python manage.py sync_from_backend
    python manage.py sync_from_backend --backend-url http://localhost:5000
"""
from datetime import datetime

import requests
from django.core.management.base import BaseCommand

from monitoring.models import Device, Measurement, SensorType, Zone
from monitoring.services.backend_client import BackendClient


class Command(BaseCommand):
    help = "Synchronises monitoring data from the back-end REST API (Лабораторна робота №2)."

    def add_arguments(self, parser):
        parser.add_argument("--backend-url", default=None, help="Override BACKEND_API_BASE_URL.")

    def handle(self, *args, **options):
        client = BackendClient(base_url=options["backend_url"])

        try:
            client.health()
        except requests.RequestException as exc:
            self.stderr.write(self.style.ERROR(f"Back-end is unreachable at {client.base_url}: {exc}"))
            return

        zone_map = {}
        for item in client.list_zones():
            zone, _created = Zone.objects.update_or_create(
                name=item["zone_name"],
                region=item["region"],
                defaults={"latitude": item["latitude"], "longitude": item["longitude"]},
            )
            zone_map[item["zone_id"]] = zone
        self.stdout.write(f"Synced {len(zone_map)} zone(s).")

        sensor_map = {}
        for item in client.list_sensor_types():
            sensor_type, _created = SensorType.objects.update_or_create(
                code=item["code"], defaults={"name": item["sensor_name"], "unit": item["unit"]}
            )
            sensor_map[item["sensor_type_id"]] = sensor_type
        self.stdout.write(f"Synced {len(sensor_map)} sensor type(s).")

        device_map = {}
        for item in client.list_devices():
            zone = zone_map.get(item["zone_id"])
            if zone is None:
                continue
            last_seen = None
            if item.get("last_seen_at"):
                last_seen = datetime.fromisoformat(item["last_seen_at"])
            device, _created = Device.objects.update_or_create(
                serial_number=item["serial_number"],
                defaults={"zone": zone, "status": item["status"], "last_seen_at": last_seen},
            )
            device_map[item["device_id"]] = device
        self.stdout.write(f"Synced {len(device_map)} device(s).")

        created_count = 0
        for item in client.list_measurements(limit=2000):
            device = device_map.get(item["device_id"])
            sensor_type = sensor_map.get(item["sensor_type_id"])
            if device is None or sensor_type is None:
                continue
            _obj, created = Measurement.objects.get_or_create(
                device=device,
                sensor_type=sensor_type,
                measured_at=datetime.fromisoformat(item["measured_at"]),
                defaults={"value": item["value"], "quality_flag": item.get("quality_flag", "OK")},
            )
            if created:
                created_count += 1
        self.stdout.write(self.style.SUCCESS(f"Synced {created_count} new measurement(s)."))
