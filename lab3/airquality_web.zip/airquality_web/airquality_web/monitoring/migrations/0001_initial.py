import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name="SensorType",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("code", models.CharField(max_length=50, unique=True, verbose_name="Code")),
                ("name", models.CharField(max_length=200, verbose_name="Name")),
                ("unit", models.CharField(max_length=50, verbose_name="Unit")),
            ],
            options={
                "verbose_name": "Sensor type",
                "verbose_name_plural": "Sensor types",
                "ordering": ["code"],
            },
        ),
        migrations.CreateModel(
            name="Zone",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("name", models.CharField(max_length=200, verbose_name="Zone name")),
                ("region", models.CharField(max_length=200, verbose_name="Region")),
                ("latitude", models.DecimalField(decimal_places=6, max_digits=9, verbose_name="Latitude")),
                ("longitude", models.DecimalField(decimal_places=6, max_digits=9, verbose_name="Longitude")),
                ("created_at", models.DateTimeField(auto_now_add=True, verbose_name="Created at")),
            ],
            options={
                "verbose_name": "Monitoring zone",
                "verbose_name_plural": "Monitoring zones",
                "ordering": ["region", "name"],
                "unique_together": {("region", "name")},
            },
        ),
        migrations.CreateModel(
            name="Device",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("serial_number", models.CharField(max_length=100, unique=True, verbose_name="Serial number")),
                (
                    "status",
                    models.CharField(
                        choices=[("ONLINE", "Online"), ("OFFLINE", "Offline")],
                        default="OFFLINE",
                        max_length=20,
                        verbose_name="Status",
                    ),
                ),
                ("last_seen_at", models.DateTimeField(blank=True, null=True, verbose_name="Last seen at")),
                ("installed_at", models.DateTimeField(auto_now_add=True, verbose_name="Installed at")),
                (
                    "zone",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="devices",
                        to="monitoring.zone",
                        verbose_name="Zone",
                    ),
                ),
            ],
            options={
                "verbose_name": "Device",
                "verbose_name_plural": "Devices",
                "ordering": ["serial_number"],
            },
        ),
        migrations.CreateModel(
            name="Measurement",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("value", models.DecimalField(decimal_places=6, max_digits=14, verbose_name="Value")),
                ("measured_at", models.DateTimeField(verbose_name="Measured at")),
                ("received_at", models.DateTimeField(auto_now_add=True, verbose_name="Received at")),
                (
                    "quality_flag",
                    models.CharField(
                        choices=[("OK", "OK"), ("SUSPECT", "Suspect"), ("ERROR", "Error")],
                        default="OK",
                        max_length=20,
                        verbose_name="Quality flag",
                    ),
                ),
                (
                    "device",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="measurements",
                        to="monitoring.device",
                        verbose_name="Device",
                    ),
                ),
                (
                    "sensor_type",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="measurements",
                        to="monitoring.sensortype",
                        verbose_name="Sensor type",
                    ),
                ),
            ],
            options={
                "verbose_name": "Measurement",
                "verbose_name_plural": "Measurements",
                "ordering": ["-measured_at"],
            },
        ),
        migrations.AddIndex(
            model_name="measurement",
            index=models.Index(fields=["sensor_type", "measured_at"], name="monitoring__sensor__d80a47_idx"),
        ),
        migrations.CreateModel(
            name="FavoriteZone",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                (
                    "user",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="favorite_zones",
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
                (
                    "zone",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="favorited_by",
                        to="monitoring.zone",
                    ),
                ),
            ],
            options={
                "verbose_name": "Favorite zone",
                "verbose_name_plural": "Favorite zones",
                "unique_together": {("user", "zone")},
            },
        ),
    ]
