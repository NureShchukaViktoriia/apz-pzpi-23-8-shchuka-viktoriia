import csv
import json
from datetime import timedelta

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, redirect
from django.urls import reverse
from django.utils import timezone
from django.utils.translation import gettext as _
from django.views.generic import DetailView, ListView, TemplateView

from .models import Device, FavoriteZone, Measurement, SensorType, Zone
from .services.aqi import zone_aqi
from .utils.sorting import localized_sort


class DashboardView(TemplateView):

    template_name = "monitoring/dashboard.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        zones = Zone.objects.all()
        context["zone_count"] = zones.count()
        context["device_online_count"] = Device.objects.filter(status=Device.Status.ONLINE).count()
        context["device_offline_count"] = Device.objects.filter(status=Device.Status.OFFLINE).count()
        context["measurement_count_24h"] = Measurement.objects.filter(
            measured_at__gte=timezone.now() - timedelta(hours=24)
        ).count()
        return context


def zones_geojson(request):
    """JSON feed consumed by the Leaflet map on the dashboard page.

    Kept as a small first-party JSON endpoint (not a public REST API -
    that responsibility belongs to the back-end built in Лабораторна
    робота №2). It only serves the front-end's own templates/JS.
    """
    features = []
    for zone in Zone.objects.all():
        readings = zone.latest_reading_per_sensor()
        category = zone_aqi(readings)
        features.append(
            {
                "id": zone.pk,
                "name": zone.name,
                "region": zone.region,
                "lat": float(zone.latitude),
                "lng": float(zone.longitude),
                "aqi_key": category.key if category else "no_data",
                "aqi_color": category.color if category else "#95a5a6",
                "url": reverse("monitoring:zone_detail", args=[zone.pk]),
            }
        )
    return JsonResponse({"zones": features})


class ZoneListView(ListView):
    model = Zone
    template_name = "monitoring/zone_list.html"
    context_object_name = "zones"

    def get_queryset(self):
        queryset = super().get_queryset()
        return localized_sort(queryset, key=lambda zone: zone.name)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        zones_with_aqi = []
        for zone in context["zones"]:
            readings = zone.latest_reading_per_sensor()
            zones_with_aqi.append((zone, zone_aqi(readings)))
        context["zones_with_aqi"] = zones_with_aqi
        if self.request.user.is_authenticated:
            context["favorite_ids"] = set(
                FavoriteZone.objects.filter(user=self.request.user).values_list("zone_id", flat=True)
            )
        return context


class ZoneDetailView(DetailView):
    model = Zone
    template_name = "monitoring/zone_detail.html"
    context_object_name = "zone"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        zone = self.object
        readings = zone.latest_reading_per_sensor()
        context["readings"] = readings
        context["aqi"] = zone_aqi(readings)
        context["devices"] = zone.devices.all().order_by("serial_number")
        context["sensor_types"] = localized_sort(SensorType.objects.all(), key=lambda s: s.name)
        if self.request.user.is_authenticated:
            context["is_favorite"] = FavoriteZone.objects.filter(user=self.request.user, zone=zone).exists()
        return context


def zone_chart_data(request, pk):
    """JSON time series for Chart.js, scoped to one zone + sensor type."""
    zone = get_object_or_404(Zone, pk=pk)
    sensor_code = request.GET.get("sensor", "")
    hours = int(request.GET.get("hours", 24))
    since = timezone.now() - timedelta(hours=hours)

    qs = (
        Measurement.objects.filter(device__zone=zone, measured_at__gte=since)
        .select_related("sensor_type")
        .order_by("measured_at")
    )
    if sensor_code:
        qs = qs.filter(sensor_type__code=sensor_code)

    labels = [m.measured_at.isoformat() for m in qs]
    values = [float(m.value) for m in qs]
    return JsonResponse({"labels": labels, "values": values})


@login_required
def toggle_favorite_zone(request, pk):
    zone = get_object_or_404(Zone, pk=pk)
    favorite, created = FavoriteZone.objects.get_or_create(user=request.user, zone=zone)
    if not created:
        favorite.delete()
        messages.info(request, _("Removed from favorites."))
    else:
        messages.success(request, _("Added to favorites."))
    return redirect(request.META.get("HTTP_REFERER") or zone.get_absolute_url())


class DeviceListView(ListView):
    model = Device
    template_name = "monitoring/device_list.html"
    context_object_name = "devices"

    def get_queryset(self):
        queryset = Device.objects.select_related("zone").all()
        zone_id = self.request.GET.get("zone")
        status = self.request.GET.get("status")
        if zone_id:
            queryset = queryset.filter(zone_id=zone_id)
        if status:
            queryset = queryset.filter(status=status)
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["zones"] = localized_sort(Zone.objects.all(), key=lambda zone: zone.name)
        context["statuses"] = Device.Status.choices
        return context


class DeviceDetailView(DetailView):
    model = Device
    template_name = "monitoring/device_detail.html"
    context_object_name = "device"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["recent_measurements"] = (
            self.object.measurements.select_related("sensor_type").order_by("-measured_at")[:50]
        )
        return context


class SensorTypeListView(ListView):
    model = SensorType
    template_name = "monitoring/sensor_type_list.html"
    context_object_name = "sensor_types"

    def get_queryset(self):
        return localized_sort(SensorType.objects.all(), key=lambda sensor: sensor.name)


class MeasurementExportView(TemplateView):
    """Implements MF-6 ("експорт результатів вимірювань і звітів у
    форматах CSV ... або JSON")."""

    template_name = "monitoring/measurement_export.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["zones"] = localized_sort(Zone.objects.all(), key=lambda zone: zone.name)
        context["sensor_types"] = localized_sort(SensorType.objects.all(), key=lambda s: s.name)
        return context

    def get(self, request, *args, **kwargs):
        export_format = request.GET.get("format")
        if export_format not in ("csv", "json"):
            return super().get(request, *args, **kwargs)

        queryset = Measurement.objects.select_related("device", "sensor_type", "device__zone").order_by(
            "-measured_at"
        )
        zone_id = request.GET.get("zone")
        sensor_code = request.GET.get("sensor")
        if zone_id:
            queryset = queryset.filter(device__zone_id=zone_id)
        if sensor_code:
            queryset = queryset.filter(sensor_type__code=sensor_code)
        queryset = queryset[:5000]

        if export_format == "csv":
            response = HttpResponse(content_type="text/csv")
            response["Content-Disposition"] = 'attachment; filename="measurements.csv"'
            writer = csv.writer(response)
            writer.writerow(["zone", "device", "sensor", "unit", "value", "measured_at", "quality_flag"])
            for m in queryset:
                writer.writerow(
                    [
                        m.device.zone.name,
                        m.device.serial_number,
                        m.sensor_type.code,
                        m.sensor_type.unit,
                        m.value,
                        m.measured_at.isoformat(),
                        m.quality_flag,
                    ]
                )
            return response

        data = [
            {
                "zone": m.device.zone.name,
                "device": m.device.serial_number,
                "sensor": m.sensor_type.code,
                "unit": m.sensor_type.unit,
                "value": float(m.value),
                "measured_at": m.measured_at.isoformat(),
                "quality_flag": m.quality_flag,
            }
            for m in queryset
        ]
        response = HttpResponse(
            json.dumps(data, ensure_ascii=False, indent=2), content_type="application/json"
        )
        response["Content-Disposition"] = 'attachment; filename="measurements.json"'
        return response
