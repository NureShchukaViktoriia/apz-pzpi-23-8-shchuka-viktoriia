
from django.conf import settings
from django.db import models
from django.urls import reverse
from django.utils.translation import gettext_lazy as _


class Zone(models.Model):
    """A geographic monitoring zone (e.g. a city district or industrial area)."""

    name = models.CharField(max_length=200, verbose_name=_("Zone name"))
    region = models.CharField(max_length=200, verbose_name=_("Region"))
    latitude = models.DecimalField(max_digits=9, decimal_places=6, verbose_name=_("Latitude"))
    longitude = models.DecimalField(max_digits=9, decimal_places=6, verbose_name=_("Longitude"))
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_("Created at"))

    class Meta:
        unique_together = ("region", "name")
        ordering = ["region", "name"]
        verbose_name = _("Monitoring zone")
        verbose_name_plural = _("Monitoring zones")

    def __str__(self):
        return f"{self.name} ({self.region})"

    def get_absolute_url(self):
        return reverse("monitoring:zone_detail", args=[self.pk])

    def latest_reading_per_sensor(self):
        """Returns the most recent Measurement for every sensor type
        observed in this zone, used to compute the zone's current AQI."""
        readings = {}
        qs = (
            Measurement.objects.filter(device__zone=self)
            .select_related("sensor_type", "device")
            .order_by("-measured_at")
        )
        for measurement in qs:
            code = measurement.sensor_type.code
            if code not in readings:
                readings[code] = measurement
        return readings


class Device(models.Model):
    """An IoT measuring device installed within a Zone."""

    class Status(models.TextChoices):
        ONLINE = "ONLINE", _("Online")
        OFFLINE = "OFFLINE", _("Offline")

    serial_number = models.CharField(max_length=100, unique=True, verbose_name=_("Serial number"))
    zone = models.ForeignKey(Zone, on_delete=models.CASCADE, related_name="devices", verbose_name=_("Zone"))
    status = models.CharField(
        max_length=20, choices=Status.choices, default=Status.OFFLINE, verbose_name=_("Status")
    )
    last_seen_at = models.DateTimeField(null=True, blank=True, verbose_name=_("Last seen at"))
    installed_at = models.DateTimeField(auto_now_add=True, verbose_name=_("Installed at"))

    class Meta:
        ordering = ["serial_number"]
        verbose_name = _("Device")
        verbose_name_plural = _("Devices")

    def __str__(self):
        return self.serial_number

    def get_absolute_url(self):
        return reverse("monitoring:device_detail", args=[self.pk])


class SensorType(models.Model):
    """A reference (lookup) record describing a kind of measurement."""

    code = models.CharField(max_length=50, unique=True, verbose_name=_("Code"))
    name = models.CharField(max_length=200, verbose_name=_("Name"))
    unit = models.CharField(max_length=50, verbose_name=_("Unit"))

    class Meta:
        ordering = ["code"]
        verbose_name = _("Sensor type")
        verbose_name_plural = _("Sensor types")

    def __str__(self):
        return f"{self.name} ({self.unit})"


class Measurement(models.Model):
    """A single sensor reading sent by a Device."""

    class Quality(models.TextChoices):
        OK = "OK", _("OK")
        SUSPECT = "SUSPECT", _("Suspect")
        ERROR = "ERROR", _("Error")

    device = models.ForeignKey(Device, on_delete=models.CASCADE, related_name="measurements", verbose_name=_("Device"))
    sensor_type = models.ForeignKey(
        SensorType, on_delete=models.CASCADE, related_name="measurements", verbose_name=_("Sensor type")
    )
    value = models.DecimalField(max_digits=14, decimal_places=6, verbose_name=_("Value"))
    measured_at = models.DateTimeField(verbose_name=_("Measured at"))
    received_at = models.DateTimeField(auto_now_add=True, verbose_name=_("Received at"))
    quality_flag = models.CharField(
        max_length=20, choices=Quality.choices, default=Quality.OK, verbose_name=_("Quality flag")
    )

    class Meta:
        ordering = ["-measured_at"]
        indexes = [models.Index(fields=["sensor_type", "measured_at"])]
        verbose_name = _("Measurement")
        verbose_name_plural = _("Measurements")

    def __str__(self):
        return f"{self.sensor_type.code}={self.value} @ {self.measured_at:%Y-%m-%d %H:%M}"


class FavoriteZone(models.Model):
    """Lets an authenticated user bookmark zones they want to track closely."""

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="favorite_zones")
    zone = models.ForeignKey(Zone, on_delete=models.CASCADE, related_name="favorited_by")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("user", "zone")
        verbose_name = _("Favorite zone")
        verbose_name_plural = _("Favorite zones")

    def __str__(self):
        return f"{self.user} -> {self.zone}"
