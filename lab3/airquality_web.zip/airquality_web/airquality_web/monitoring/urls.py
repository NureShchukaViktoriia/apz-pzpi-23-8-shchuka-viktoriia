from django.urls import path

from . import views

app_name = "monitoring"

urlpatterns = [
    path("", views.DashboardView.as_view(), name="dashboard"),
    path("api/zones.geojson", views.zones_geojson, name="zones_geojson"),
    path("zones/", views.ZoneListView.as_view(), name="zone_list"),
    path("zones/<int:pk>/", views.ZoneDetailView.as_view(), name="zone_detail"),
    path("zones/<int:pk>/chart-data/", views.zone_chart_data, name="zone_chart_data"),
    path("zones/<int:pk>/favorite/", views.toggle_favorite_zone, name="toggle_favorite_zone"),
    path("devices/", views.DeviceListView.as_view(), name="device_list"),
    path("devices/<int:pk>/", views.DeviceDetailView.as_view(), name="device_detail"),
    path("sensor-types/", views.SensorTypeListView.as_view(), name="sensor_type_list"),
    path("export/", views.MeasurementExportView.as_view(), name="measurement_export"),
]
