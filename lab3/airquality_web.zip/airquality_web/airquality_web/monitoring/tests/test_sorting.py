from django.test import SimpleTestCase

from monitoring.utils.sorting import localized_sort


class LocalizedSortTests(SimpleTestCase):
    def test_ukrainian_alphabet_order(self):
        # "Ї" sorts after "І" and before "Й" in the Ukrainian alphabet,
        # unlike a naive Unicode code-point sort.
        words = ["Йорж", "Їжак", "Іриска"]
        result = localized_sort(words, key=lambda w: w, language="uk")
        self.assertEqual(result, ["Іриска", "Їжак", "Йорж"])

    def test_english_case_insensitive(self):
        words = ["banana", "Apple", "cherry"]
        result = localized_sort(words, key=lambda w: w, language="en")
        self.assertEqual(result, ["Apple", "banana", "cherry"])

    def test_reverse_order(self):
        words = ["a", "b", "c"]
        result = localized_sort(words, key=lambda w: w, language="en", reverse=True)
        self.assertEqual(result, ["c", "b", "a"])
