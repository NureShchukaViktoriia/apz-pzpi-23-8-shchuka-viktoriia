from django.test import SimpleTestCase

from monitoring.services.aqi import categorize, zone_aqi


class FakeMeasurement:
    def __init__(self, value):
        self.value = value


class CategorizeTests(SimpleTestCase):
    def test_good_category(self):
        category = categorize("CO2", 500)
        self.assertEqual(category.key, "good")

    def test_hazardous_category(self):
        category = categorize("CO2", 5000)
        self.assertEqual(category.key, "hazardous")

    def test_unknown_sensor_returns_none(self):
        self.assertIsNone(categorize("TEMPERATURE", 20))

    def test_case_insensitive_code(self):
        category = categorize("co2", 500)
        self.assertEqual(category.key, "good")


class ZoneAqiTests(SimpleTestCase):
    def test_worst_pollutant_wins(self):
        readings = {
            "CO2": FakeMeasurement(500),  # good
            "NO2": FakeMeasurement(700),  # hazardous
        }
        category = zone_aqi(readings)
        self.assertEqual(category.key, "hazardous")

    def test_no_relevant_pollutants_returns_none(self):
        readings = {"TEMPERATURE": FakeMeasurement(21)}
        self.assertIsNone(zone_aqi(readings))

    def test_empty_readings_returns_none(self):
        self.assertIsNone(zone_aqi({}))
