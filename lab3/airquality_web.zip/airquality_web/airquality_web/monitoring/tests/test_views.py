from django.test import TestCase
from django.urls import reverse

from accounts.models import CustomUser
from monitoring.models import Device, SensorType, Zone


class MonitoringViewsTests(TestCase):
    def setUp(self):
        self.zone = Zone.objects.create(name="Центр", region="Харків", latitude=49.99, longitude=36.23)
        self.sensor = SensorType.objects.create(code="CO2", name="Діоксид вуглецю", unit="ppm")
        self.device = Device.objects.create(serial_number="DEV-001", zone=self.zone, status=Device.Status.ONLINE)

    def test_dashboard_loads(self):
        response = self.client.get(reverse("monitoring:dashboard"))
        self.assertEqual(response.status_code, 200)

    def test_zone_list_loads_and_contains_zone(self):
        response = self.client.get(reverse("monitoring:zone_list"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Центр")

    def test_zone_detail_loads(self):
        response = self.client.get(reverse("monitoring:zone_detail", args=[self.zone.pk]))
        self.assertEqual(response.status_code, 200)

    def test_zones_geojson_returns_zone(self):
        response = self.client.get(reverse("monitoring:zones_geojson"))
        self.assertEqual(response.status_code, 200)
        self.assertIn("zones", response.json())
        self.assertEqual(len(response.json()["zones"]), 1)

    def test_export_csv(self):
        response = self.client.get(reverse("monitoring:measurement_export"), {"format": "csv"})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response["Content-Type"], "text/csv")


class AdminPanelAccessTests(TestCase):
    def setUp(self):
        self.viewer = CustomUser.objects.create_user(username="viewer", password="pass12345", role=CustomUser.Role.VIEWER)
        self.admin = CustomUser.objects.create_user(username="boss", password="pass12345", role=CustomUser.Role.ADMIN)

    def test_anonymous_redirected_to_login(self):
        response = self.client.get(reverse("adminpanel:dashboard"))
        self.assertEqual(response.status_code, 302)
        self.assertIn(reverse("accounts:login"), response.url)

    def test_viewer_forbidden(self):
        self.client.login(username="viewer", password="pass12345")
        response = self.client.get(reverse("adminpanel:dashboard"))
        self.assertEqual(response.status_code, 403)

    def test_admin_allowed(self):
        self.client.login(username="boss", password="pass12345")
        response = self.client.get(reverse("adminpanel:dashboard"))
        self.assertEqual(response.status_code, 200)
