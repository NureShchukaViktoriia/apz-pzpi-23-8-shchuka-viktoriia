from django.contrib import admin

from .models import Device, FavoriteZone, Measurement, SensorType, Zone


@admin.register(Zone)
class ZoneAdmin(admin.ModelAdmin):
    list_display = ("name", "region", "latitude", "longitude", "created_at")
    list_filter = ("region",)
    search_fields = ("name", "region")


@admin.register(Device)
class DeviceAdmin(admin.ModelAdmin):
    list_display = ("serial_number", "zone", "status", "last_seen_at")
    list_filter = ("status", "zone")
    search_fields = ("serial_number",)
    autocomplete_fields = ["zone"]


@admin.register(SensorType)
class SensorTypeAdmin(admin.ModelAdmin):
    list_display = ("code", "name", "unit")
    search_fields = ("code", "name")


@admin.register(Measurement)
class MeasurementAdmin(admin.ModelAdmin):
    list_display = ("device", "sensor_type", "value", "measured_at", "quality_flag")
    list_filter = ("quality_flag", "sensor_type")
    date_hierarchy = "measured_at"
    autocomplete_fields = ["device", "sensor_type"]


@admin.register(FavoriteZone)
class FavoriteZoneAdmin(admin.ModelAdmin):
    list_display = ("user", "zone", "created_at")
