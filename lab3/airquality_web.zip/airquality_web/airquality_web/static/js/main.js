// Project-wide small enhancements. Page-specific interactive logic
// (the Leaflet map, Chart.js graphs) lives in extra_scripts blocks of
// the relevant templates, since it depends on data only those views
// provide.

document.addEventListener("DOMContentLoaded", function () {
    // Auto-dismiss alert messages after a few seconds.
    document.querySelectorAll(".alert").forEach(function (alertEl) {
        setTimeout(function () {
            alertEl.classList.remove("show");
        }, 6000);
    });
});
