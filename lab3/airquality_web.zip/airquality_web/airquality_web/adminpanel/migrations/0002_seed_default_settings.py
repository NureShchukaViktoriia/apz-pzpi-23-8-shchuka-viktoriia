from django.db import migrations

DEFAULT_SETTINGS = [
    ("site_name", "AirWatch", "Name shown in the navigation bar."),
    ("default_language", "uk", "Default UI language for new sessions."),
    ("aqi_model", "simplified-v1", "Identifier of the AQI breakpoint table in use."),
    ("data_retention_days", "365", "How long raw measurements are kept before archival."),
]


def seed_settings(apps, schema_editor):
    SystemSetting = apps.get_model("adminpanel", "SystemSetting")
    for key, value, description in DEFAULT_SETTINGS:
        SystemSetting.objects.get_or_create(key=key, defaults={"value": value, "description": description})


def remove_settings(apps, schema_editor):
    SystemSetting = apps.get_model("adminpanel", "SystemSetting")
    SystemSetting.objects.filter(key__in=[k for k, _v, _d in DEFAULT_SETTINGS]).delete()


class Migration(migrations.Migration):

    dependencies = [
        ("adminpanel", "0001_initial"),
    ]

    operations = [
        migrations.RunPython(seed_settings, remove_settings),
    ]
