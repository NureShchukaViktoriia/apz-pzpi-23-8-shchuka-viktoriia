import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name="SystemSetting",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("key", models.CharField(max_length=100, unique=True, verbose_name="Key")),
                ("value", models.CharField(max_length=500, verbose_name="Value")),
                ("description", models.CharField(blank=True, max_length=255, verbose_name="Description")),
                ("updated_at", models.DateTimeField(auto_now=True, verbose_name="Updated at")),
            ],
            options={
                "verbose_name": "System setting",
                "verbose_name_plural": "System settings",
                "ordering": ["key"],
            },
        ),
        migrations.CreateModel(
            name="BackupRecord",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                (
                    "kind",
                    models.CharField(
                        choices=[
                            ("full", "Full backup (data + settings)"),
                            ("data", "Data only"),
                            ("settings", "Settings only"),
                        ],
                        default="full",
                        max_length=20,
                        verbose_name="Kind",
                    ),
                ),
                ("file_name", models.CharField(max_length=255, verbose_name="File name")),
                ("created_at", models.DateTimeField(auto_now_add=True, verbose_name="Created at")),
                ("size_bytes", models.PositiveBigIntegerField(default=0, verbose_name="Size (bytes)")),
                (
                    "created_by",
                    models.ForeignKey(
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="backups",
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
            ],
            options={
                "verbose_name": "Backup",
                "verbose_name_plural": "Backups",
                "ordering": ["-created_at"],
            },
        ),
    ]
