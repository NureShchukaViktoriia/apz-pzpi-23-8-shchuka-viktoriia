"""
Models that exist purely to support the administration interface:

* SystemSetting  - simple key/value application configuration ("settings"
  in "резервні копії налаштувань та даних" - backups of settings AND
  data are explicitly required, so settings need to be modelled as data
  in their own right, distinct from the monitoring domain models).
* BackupRecord   - a log entry for every backup created through the
  admin interface (who created it, when, which file).
"""
from django.conf import settings
from django.db import models
from django.utils.translation import gettext_lazy as _


class SystemSetting(models.Model):
    key = models.CharField(max_length=100, unique=True, verbose_name=_("Key"))
    value = models.CharField(max_length=500, verbose_name=_("Value"))
    description = models.CharField(max_length=255, blank=True, verbose_name=_("Description"))
    updated_at = models.DateTimeField(auto_now=True, verbose_name=_("Updated at"))

    class Meta:
        ordering = ["key"]
        verbose_name = _("System setting")
        verbose_name_plural = _("System settings")

    def __str__(self):
        return f"{self.key} = {self.value}"


class BackupRecord(models.Model):
    class Kind(models.TextChoices):
        FULL = "full", _("Full backup (data + settings)")
        DATA_ONLY = "data", _("Data only")
        SETTINGS_ONLY = "settings", _("Settings only")

    kind = models.CharField(max_length=20, choices=Kind.choices, default=Kind.FULL, verbose_name=_("Kind"))
    file_name = models.CharField(max_length=255, verbose_name=_("File name"))
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name="backups"
    )
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_("Created at"))
    size_bytes = models.PositiveBigIntegerField(default=0, verbose_name=_("Size (bytes)"))

    class Meta:
        ordering = ["-created_at"]
        verbose_name = _("Backup")
        verbose_name_plural = _("Backups")

    def __str__(self):
        return self.file_name
