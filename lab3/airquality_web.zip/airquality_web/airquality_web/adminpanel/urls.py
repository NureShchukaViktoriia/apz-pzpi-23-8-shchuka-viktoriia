from django.urls import path

from . import views

app_name = "adminpanel"

urlpatterns = [
    path("", views.AdminDashboardView.as_view(), name="dashboard"),

    path("users/", views.UserListView.as_view(), name="user_list"),
    path("users/new/", views.UserCreateView.as_view(), name="user_create"),
    path("users/<int:pk>/edit/", views.UserUpdateView.as_view(), name="user_update"),
    path("users/<int:pk>/toggle-active/", views.user_toggle_active, name="user_toggle_active"),

    path("settings/", views.SystemSettingListView.as_view(), name="setting_list"),
    path("settings/new/", views.SystemSettingCreateView.as_view(), name="setting_create"),
    path("settings/<int:pk>/edit/", views.SystemSettingUpdateView.as_view(), name="setting_update"),
    path("settings/<int:pk>/delete/", views.SystemSettingDeleteView.as_view(), name="setting_delete"),

    path("backups/", views.BackupListView.as_view(), name="backup_list"),
    path("backups/create/", views.backup_create, name="backup_create"),
    path("backups/<int:pk>/download/", views.backup_download, name="backup_download"),
    path("backups/restore/", views.backup_restore, name="backup_restore"),

    path("export/", views.export_dataset, name="export_dataset"),
    path("import/", views.import_dataset, name="import_dataset"),
]
