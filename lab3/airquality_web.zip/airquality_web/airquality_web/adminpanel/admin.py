from django.contrib import admin

from .models import BackupRecord, SystemSetting


@admin.register(SystemSetting)
class SystemSettingAdmin(admin.ModelAdmin):
    list_display = ("key", "value", "updated_at")
    search_fields = ("key",)


@admin.register(BackupRecord)
class BackupRecordAdmin(admin.ModelAdmin):
    list_display = ("file_name", "kind", "created_by", "created_at", "size_bytes")
    list_filter = ("kind",)
    readonly_fields = ("created_at",)
