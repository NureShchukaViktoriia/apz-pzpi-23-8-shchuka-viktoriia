from django import forms
from django.utils.translation import gettext_lazy as _

from accounts.models import CustomUser

from .models import SystemSetting


class AdminUserCreateForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput, label=_("Password"))

    class Meta:
        model = CustomUser
        fields = ["username", "email", "first_name", "last_name", "role", "organization", "is_active"]

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data["password"])
        if commit:
            user.save()
        return user


class AdminUserUpdateForm(forms.ModelForm):
    class Meta:
        model = CustomUser
        fields = ["email", "first_name", "last_name", "role", "organization", "is_active"]


class BackupCreateForm(forms.Form):
    KIND_CHOICES = [
        ("full", _("Full backup (data + settings)")),
        ("data", _("Monitoring data only")),
        ("settings", _("System settings only")),
    ]
    kind = forms.ChoiceField(choices=KIND_CHOICES, label=_("Backup scope"))


class RestoreForm(forms.Form):
    backup_file = forms.FileField(required=False, label=_("Upload backup file"))
    existing_file = forms.CharField(required=False, widget=forms.HiddenInput)
    confirm = forms.BooleanField(
        label=_("I understand this will overwrite existing records with matching IDs."), required=True
    )

    def clean(self):
        cleaned = super().clean()
        if not cleaned.get("backup_file") and not cleaned.get("existing_file"):
            raise forms.ValidationError(_("Choose a file to upload or select an existing backup."))
        return cleaned


DATASET_CHOICES = [
    ("zones", _("Monitoring zones")),
    ("sensor_types", _("Sensor types")),
    ("devices", _("Devices")),
    ("settings", _("System settings")),
]

FORMAT_CHOICES = [("csv", "CSV"), ("json", "JSON")]


class ExportForm(forms.Form):
    dataset = forms.ChoiceField(choices=DATASET_CHOICES, label=_("Dataset"))
    fmt = forms.ChoiceField(choices=FORMAT_CHOICES, label=_("Format"))


class ImportForm(forms.Form):
    dataset = forms.ChoiceField(choices=DATASET_CHOICES, label=_("Dataset"))
    fmt = forms.ChoiceField(choices=FORMAT_CHOICES, label=_("Format"))
    data_file = forms.FileField(label=_("File"))


class SystemSettingForm(forms.ModelForm):
    class Meta:
        model = SystemSetting
        fields = ["key", "value", "description"]
