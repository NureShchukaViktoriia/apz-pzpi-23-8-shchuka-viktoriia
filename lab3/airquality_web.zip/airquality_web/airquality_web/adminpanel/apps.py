from django.apps import AppConfig
from django.utils.translation import gettext_lazy as _


class AdminpanelConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "adminpanel"
    verbose_name = _("System administration")
