from functools import wraps
from pathlib import Path

from django.contrib import messages
from django.contrib.auth.views import redirect_to_login
from django.core.exceptions import PermissionDenied
from django.http import FileResponse, HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse_lazy
from django.utils.translation import gettext_lazy as _
from django.views.generic import CreateView, DeleteView, ListView, TemplateView, UpdateView
from django.conf import settings as django_settings

from accounts.mixins import AdminRoleRequiredMixin
from accounts.models import CustomUser
from monitoring.models import Device, Measurement, SensorType, Zone

from .forms import (
    AdminUserCreateForm,
    AdminUserUpdateForm,
    BackupCreateForm,
    ExportForm,
    ImportForm,
    RestoreForm,
    SystemSettingForm,
)
from .models import BackupRecord, SystemSetting
from .services import backup as backup_service
from .services import data_io


def admin_required(view_func):
    """Function-view decorator counterpart of AdminRoleRequiredMixin.

    Anonymous users are sent to the login page (with a `next` redirect);
    authenticated users without the admin role get an explicit 403,
    matching the behaviour of AdminRoleRequiredMixin used by the
    class-based views in this module.
    """

    @wraps(view_func)
    def _wrapped(request, *args, **kwargs):
        if not request.user.is_authenticated:
            return redirect_to_login(request.get_full_path(), login_url="accounts:login")
        if not request.user.is_admin_role:
            raise PermissionDenied("This section is only available to system administrators.")
        return view_func(request, *args, **kwargs)

    return _wrapped


class AdminDashboardView(AdminRoleRequiredMixin, TemplateView):
    template_name = "adminpanel/dashboard.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["stats"] = {
            "users": CustomUser.objects.count(),
            "zones": Zone.objects.count(),
            "devices": Device.objects.count(),
            "devices_online": Device.objects.filter(status=Device.Status.ONLINE).count(),
            "measurements": Measurement.objects.count(),
            "settings": SystemSetting.objects.count(),
        }
        context["recent_backups"] = BackupRecord.objects.all()[:5]
        return context


# ---------------------------------------------------------------------------
# User management ("управління користувачами системи")
# ---------------------------------------------------------------------------


class UserListView(AdminRoleRequiredMixin, ListView):
    model = CustomUser
    template_name = "adminpanel/user_list.html"
    context_object_name = "users"
    paginate_by = 25


class UserCreateView(AdminRoleRequiredMixin, CreateView):
    model = CustomUser
    form_class = AdminUserCreateForm
    template_name = "adminpanel/user_form.html"
    success_url = reverse_lazy("adminpanel:user_list")

    def form_valid(self, form):
        response = super().form_valid(form)
        messages.success(self.request, _("User created."))
        return response


class UserUpdateView(AdminRoleRequiredMixin, UpdateView):
    model = CustomUser
    form_class = AdminUserUpdateForm
    template_name = "adminpanel/user_form.html"
    success_url = reverse_lazy("adminpanel:user_list")

    def form_valid(self, form):
        response = super().form_valid(form)
        messages.success(self.request, _("User updated."))
        return response


@admin_required
def user_toggle_active(request, pk):
    user = get_object_or_404(CustomUser, pk=pk)
    if user == request.user:
        messages.error(request, _("You cannot deactivate your own account."))
    else:
        user.is_active = not user.is_active
        user.save(update_fields=["is_active"])
        messages.success(request, _("User status updated."))
    return redirect("adminpanel:user_list")


# ---------------------------------------------------------------------------
# System settings ("управління даними системи" - configuration data)
# ---------------------------------------------------------------------------


class SystemSettingListView(AdminRoleRequiredMixin, ListView):
    model = SystemSetting
    template_name = "adminpanel/setting_list.html"
    context_object_name = "settings_list"


class SystemSettingCreateView(AdminRoleRequiredMixin, CreateView):
    model = SystemSetting
    form_class = SystemSettingForm
    template_name = "adminpanel/setting_form.html"
    success_url = reverse_lazy("adminpanel:setting_list")


class SystemSettingUpdateView(AdminRoleRequiredMixin, UpdateView):
    model = SystemSetting
    form_class = SystemSettingForm
    template_name = "adminpanel/setting_form.html"
    success_url = reverse_lazy("adminpanel:setting_list")


class SystemSettingDeleteView(AdminRoleRequiredMixin, DeleteView):
    model = SystemSetting
    template_name = "adminpanel/setting_confirm_delete.html"
    success_url = reverse_lazy("adminpanel:setting_list")


# ---------------------------------------------------------------------------
# Backups ("створення резервних копій налаштувань та даних")
# ---------------------------------------------------------------------------


class BackupListView(AdminRoleRequiredMixin, TemplateView):
    template_name = "adminpanel/backup_list.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["create_form"] = BackupCreateForm()
        context["restore_form"] = RestoreForm()
        context["backups"] = BackupRecord.objects.all()
        return context


@admin_required
def backup_create(request):
    if request.method == "POST":
        form = BackupCreateForm(request.POST)
        if form.is_valid():
            kind = form.cleaned_data["kind"]
            file_path = backup_service.create_backup(kind)
            BackupRecord.objects.create(
                kind=kind,
                file_name=file_path.name,
                created_by=request.user,
                size_bytes=file_path.stat().st_size,
            )
            messages.success(request, _("Backup '%(name)s' created.") % {"name": file_path.name})
    return redirect("adminpanel:backup_list")


@admin_required
def backup_download(request, pk):
    record = get_object_or_404(BackupRecord, pk=pk)
    file_path = Path(django_settings.BACKUPS_DIR) / record.file_name
    if not file_path.exists():
        messages.error(request, _("Backup file is missing on disk."))
        return redirect("adminpanel:backup_list")
    return FileResponse(open(file_path, "rb"), as_attachment=True, filename=record.file_name)


@admin_required
def backup_restore(request):
    if request.method == "POST":
        form = RestoreForm(request.POST, request.FILES)
        if form.is_valid():
            uploaded = form.cleaned_data.get("backup_file")
            existing_name = form.cleaned_data.get("existing_file")
            try:
                if uploaded:
                    tmp_path = Path(django_settings.BACKUPS_DIR) / f"uploaded_{uploaded.name}"
                    with open(tmp_path, "wb") as fh:
                        for chunk in uploaded.chunks():
                            fh.write(chunk)
                    backup_service.restore_backup(tmp_path)
                elif existing_name:
                    backup_service.restore_backup(Path(django_settings.BACKUPS_DIR) / existing_name)
                messages.success(request, _("Backup restored successfully."))
            except Exception as exc:  # noqa: BLE001 - surface any restore error to the admin
                messages.error(request, _("Restore failed: %(error)s") % {"error": exc})
        else:
            messages.error(request, _("Please correct the errors below and confirm the restore."))
    return redirect("adminpanel:backup_list")


# ---------------------------------------------------------------------------
# Import / export of reference data and settings
# ("експорт та імпорт даних та налаштувань")
# ---------------------------------------------------------------------------


@admin_required
def export_dataset(request):
    form = ExportForm(request.GET or None)
    if request.GET and form.is_valid():
        dataset = form.cleaned_data["dataset"]
        fmt = form.cleaned_data["fmt"]
        content = data_io.EXPORTERS[dataset](fmt)
        content_type = "application/json" if fmt == "json" else "text/csv"
        response = HttpResponse(content, content_type=content_type)
        response["Content-Disposition"] = f'attachment; filename="{dataset}.{fmt}"'
        return response
    return render(request, "adminpanel/export.html", {"form": form})


@admin_required
def import_dataset(request):
    result = None
    if request.method == "POST":
        form = ImportForm(request.POST, request.FILES)
        if form.is_valid():
            dataset = form.cleaned_data["dataset"]
            fmt = form.cleaned_data["fmt"]
            data_file = form.cleaned_data["data_file"]
            result = data_io.IMPORTERS[dataset](data_file, fmt)
            messages.success(
                request,
                _("Import finished: %(created)s created, %(updated)s updated, %(errors)s error(s).")
                % {"created": result.created, "updated": result.updated, "errors": len(result.errors)},
            )
    else:
        form = ImportForm()
    return render(request, "adminpanel/import.html", {"form": form, "result": result})
