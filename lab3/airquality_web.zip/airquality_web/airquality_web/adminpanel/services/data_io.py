"""
Bulk import / export of reference/configuration data for the
administration interface ("експорт та імпорт даних та налаштувань").

This complements monitoring.views.MeasurementExportView (which lets any
user export raw measurement readings) with administrator-level bulk
import/export of the *configuration* entities: zones, devices, sensor
types and system settings. Both CSV and JSON are supported, per MF-6.
"""
import csv
import io
import json
from dataclasses import dataclass, field

from adminpanel.models import SystemSetting
from monitoring.models import Device, SensorType, Zone


@dataclass
class ImportResult:
    created: int = 0
    updated: int = 0
    errors: list = field(default_factory=list)


# ---------------------------------------------------------------------------
# Zones
# ---------------------------------------------------------------------------

ZONE_FIELDS = ["name", "region", "latitude", "longitude"]


def export_zones(fmt: str) -> str:
    rows = [
        {"name": z.name, "region": z.region, "latitude": str(z.latitude), "longitude": str(z.longitude)}
        for z in Zone.objects.all()
    ]
    return _serialize(rows, ZONE_FIELDS, fmt)


def import_zones(fileobj, fmt: str) -> ImportResult:
    result = ImportResult()
    for index, row in _rows(fileobj, fmt):
        try:
            _obj, created = Zone.objects.update_or_create(
                name=row["name"],
                region=row["region"],
                defaults={"latitude": row["latitude"], "longitude": row["longitude"]},
            )
            result.created += created
            result.updated += not created
        except (KeyError, ValueError) as exc:
            result.errors.append(f"Row {index}: {exc}")
    return result


# ---------------------------------------------------------------------------
# Sensor types
# ---------------------------------------------------------------------------

SENSOR_TYPE_FIELDS = ["code", "name", "unit"]


def export_sensor_types(fmt: str) -> str:
    rows = [{"code": s.code, "name": s.name, "unit": s.unit} for s in SensorType.objects.all()]
    return _serialize(rows, SENSOR_TYPE_FIELDS, fmt)


def import_sensor_types(fileobj, fmt: str) -> ImportResult:
    result = ImportResult()
    for index, row in _rows(fileobj, fmt):
        try:
            _obj, created = SensorType.objects.update_or_create(
                code=row["code"], defaults={"name": row["name"], "unit": row["unit"]}
            )
            result.created += created
            result.updated += not created
        except KeyError as exc:
            result.errors.append(f"Row {index}: missing column {exc}")
    return result


# ---------------------------------------------------------------------------
# Devices
# ---------------------------------------------------------------------------

DEVICE_FIELDS = ["serial_number", "zone_name", "zone_region", "status"]


def export_devices(fmt: str) -> str:
    rows = [
        {
            "serial_number": d.serial_number,
            "zone_name": d.zone.name,
            "zone_region": d.zone.region,
            "status": d.status,
        }
        for d in Device.objects.select_related("zone").all()
    ]
    return _serialize(rows, DEVICE_FIELDS, fmt)


def import_devices(fileobj, fmt: str) -> ImportResult:
    result = ImportResult()
    for index, row in _rows(fileobj, fmt):
        try:
            zone = Zone.objects.get(name=row["zone_name"], region=row["zone_region"])
            _obj, created = Device.objects.update_or_create(
                serial_number=row["serial_number"],
                defaults={"zone": zone, "status": row.get("status", "OFFLINE")},
            )
            result.created += created
            result.updated += not created
        except Zone.DoesNotExist:
            result.errors.append(f"Row {index}: unknown zone {row.get('zone_name')!r}")
        except KeyError as exc:
            result.errors.append(f"Row {index}: missing column {exc}")
    return result


# ---------------------------------------------------------------------------
# System settings
# ---------------------------------------------------------------------------

SETTING_FIELDS = ["key", "value", "description"]


def export_settings(fmt: str) -> str:
    rows = [{"key": s.key, "value": s.value, "description": s.description} for s in SystemSetting.objects.all()]
    return _serialize(rows, SETTING_FIELDS, fmt)


def import_settings(fileobj, fmt: str) -> ImportResult:
    result = ImportResult()
    for index, row in _rows(fileobj, fmt):
        try:
            _obj, created = SystemSetting.objects.update_or_create(
                key=row["key"], defaults={"value": row["value"], "description": row.get("description", "")}
            )
            result.created += created
            result.updated += not created
        except KeyError as exc:
            result.errors.append(f"Row {index}: missing column {exc}")
    return result


# ---------------------------------------------------------------------------
# Registry + shared helpers
# ---------------------------------------------------------------------------

EXPORTERS = {
    "zones": export_zones,
    "sensor_types": export_sensor_types,
    "devices": export_devices,
    "settings": export_settings,
}

IMPORTERS = {
    "zones": import_zones,
    "sensor_types": import_sensor_types,
    "devices": import_devices,
    "settings": import_settings,
}


def _serialize(rows: list[dict], fields: list[str], fmt: str) -> str:
    if fmt == "json":
        return json.dumps(rows, ensure_ascii=False, indent=2)
    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=fields)
    writer.writeheader()
    writer.writerows(rows)
    return buffer.getvalue()


def _rows(fileobj, fmt: str):
    if fmt == "json":
        content = fileobj.read()
        if isinstance(content, bytes):
            content = content.decode("utf-8")
        for index, row in enumerate(json.loads(content), start=1):
            yield index, row
    else:
        content = fileobj.read()
        if isinstance(content, bytes):
            content = content.decode("utf-8-sig")
        reader = csv.DictReader(io.StringIO(content))
        for index, row in enumerate(reader, start=1):
            yield index, row
