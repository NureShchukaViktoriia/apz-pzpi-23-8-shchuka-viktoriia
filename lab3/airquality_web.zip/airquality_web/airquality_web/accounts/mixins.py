"""Reusable access-control mixins for class-based views."""
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.core.exceptions import PermissionDenied
from django.utils.translation import gettext_lazy as _


class AdminRoleRequiredMixin(LoginRequiredMixin, UserPassesTestMixin):
    """Restricts a view to users with the 'admin' business role.

    Used by every view in the `adminpanel` app so that the administration
    interface stays strictly separated from the regular user interface,
    as required by the assignment ("окремий інтерфейс для звичайних
    користувачів і окремий — для адміністраторів").
    """

    permission_denied_message = _(
        "This section is only available to system administrators."
    )

    def test_func(self):
        user = self.request.user
        return user.is_authenticated and user.is_admin_role

    def handle_no_permission(self):
        if self.request.user.is_authenticated:
            raise PermissionDenied(self.permission_denied_message)
        return super().handle_no_permission()
