from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.utils.translation import gettext_lazy as _

from .models import CustomUser


class SignUpForm(UserCreationForm):
    """Public self-registration form.

    New self-registered accounts always get the 'viewer' role - elevating
    someone to 'analyst' or 'admin' is itself an administrative action and
    can only be done from the admin interface (adminpanel.views.UserUpdateView).
    """

    email = forms.EmailField(required=True, label=_("Email"))
    organization = forms.CharField(required=False, label=_("Organization"))

    class Meta:
        model = CustomUser
        fields = ["username", "email", "first_name", "last_name", "organization"]

    def save(self, commit=True):
        user = super().save(commit=False)
        user.role = CustomUser.Role.VIEWER
        user.organization = self.cleaned_data.get("organization", "")
        if commit:
            user.save()
        return user


class ProfileForm(forms.ModelForm):
    """Lets a logged-in user edit their own profile (not their role)."""

    class Meta:
        model = CustomUser
        fields = [
            "first_name",
            "last_name",
            "email",
            "organization",
            "phone",
            "preferred_language",
        ]
        widgets = {
            "preferred_language": forms.Select(),
        }
