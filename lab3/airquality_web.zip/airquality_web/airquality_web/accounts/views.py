from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse_lazy
from django.utils.translation import gettext_lazy as _
from django.views.generic import CreateView, UpdateView

from .forms import ProfileForm, SignUpForm
from .models import CustomUser


class SignUpView(CreateView):
    """Public, self-service registration (always creates a 'viewer')."""

    model = CustomUser
    form_class = SignUpForm
    template_name = "accounts/signup.html"
    success_url = reverse_lazy("monitoring:dashboard")

    def form_valid(self, form):
        response = super().form_valid(form)
        login(self.request, self.object)
        messages.success(self.request, _("Welcome! Your account has been created."))
        return response


class ProfileView(LoginRequiredMixin, UpdateView):
    """Lets the current user edit their own profile information."""

    model = CustomUser
    form_class = ProfileForm
    template_name = "accounts/profile.html"
    success_url = reverse_lazy("accounts:profile")

    def get_object(self, queryset=None):
        return self.request.user

    def form_valid(self, form):
        response = super().form_valid(form)
        messages.success(self.request, _("Profile updated."))
        return response
