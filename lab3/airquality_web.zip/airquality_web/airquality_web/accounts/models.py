"""
Custom user model.

The "role" field is the mechanism the whole project uses to tell apart the
two interfaces required by the lab assignment:

* ``Role.ADMIN``   -> gets access to the separate administration interface
                      (adminpanel app) in addition to the regular UI;
* ``Role.ANALYST``
  ``Role.VIEWER``   -> regular, user-facing interface only.

This mirrors the ``roles`` / ``user`` tables of the back-end's data model
(see air_quality_backend/models.py from Лабораторна робота №2), but the
front-end keeps its own authentication store - see the Component Diagram
in the report for the rationale (independent auth boundary per service).
"""
from django.conf import settings
from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils.translation import gettext_lazy as _


class CustomUser(AbstractUser):
    class Role(models.TextChoices):
        ADMIN = "admin", _("Administrator")
        ANALYST = "analyst", _("Environmental analyst")
        VIEWER = "viewer", _("Viewer")

    role = models.CharField(
        max_length=20,
        choices=Role.choices,
        default=Role.VIEWER,
        verbose_name=_("Role"),
        help_text=_("Determines whether the user sees the admin interface."),
    )
    organization = models.CharField(
        max_length=255, blank=True, verbose_name=_("Organization")
    )
    phone = models.CharField(max_length=30, blank=True, verbose_name=_("Phone"))
    preferred_language = models.CharField(
        max_length=10,
        choices=settings.LANGUAGES,
        blank=True,
        verbose_name=_("Preferred language"),
        help_text=_("Used as a fallback when no session language is set yet."),
    )

    class Meta:
        verbose_name = _("User")
        verbose_name_plural = _("Users")
        ordering = ["username"]

    def __str__(self):
        return self.get_full_name() or self.username

    @property
    def is_admin_role(self) -> bool:
        """True for users who should see the administration interface."""
        return self.is_superuser or self.role == self.Role.ADMIN

    def save(self, *args, **kwargs):
        # Anyone holding the "admin" business role automatically gets
        # Django's `is_staff` flag so they can also use /django-admin/
        # as a low-level data browser if needed.
        if self.role == self.Role.ADMIN:
            self.is_staff = True
        super().save(*args, **kwargs)
