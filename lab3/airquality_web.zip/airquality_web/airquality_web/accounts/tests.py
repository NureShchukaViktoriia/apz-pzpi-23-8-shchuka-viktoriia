from django.test import TestCase

from .models import CustomUser


class CustomUserRoleTests(TestCase):
    def test_admin_role_sets_is_staff(self):
        user = CustomUser.objects.create_user(username="a1", password="pass12345", role=CustomUser.Role.ADMIN)
        self.assertTrue(user.is_staff)
        self.assertTrue(user.is_admin_role)

    def test_viewer_role_is_not_admin(self):
        user = CustomUser.objects.create_user(username="v1", password="pass12345", role=CustomUser.Role.VIEWER)
        self.assertFalse(user.is_admin_role)

    def test_superuser_is_always_admin_role(self):
        user = CustomUser.objects.create_superuser(username="root", email="root@example.com", password="pass12345")
        self.assertTrue(user.is_admin_role)
